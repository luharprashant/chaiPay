package config

func Connect() {
}
